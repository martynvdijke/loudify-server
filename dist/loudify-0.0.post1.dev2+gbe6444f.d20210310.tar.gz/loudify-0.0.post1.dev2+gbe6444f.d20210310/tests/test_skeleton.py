import pytest

from loudify.skeleton import fib
from loudify.skeleton import main

__author__ = 'Martyn'
__copyright__ = 'Martyn'
__license__ = 'MIT'


def test_fib():
    """API Tests"""
    assert fib(1) == 1
    assert fib(2) == 1
    assert fib(7) == 13
    with pytest.raises(AssertionError):
        fib(-10)


def test_main(capsys):
    """CLI Tests"""
    # capsys is a pytest fixture that allows asserts agains stdout/stderr
    # https://docs.pytest.org/en/stable/capture.html
    main(['7'])
    captured = capsys.readouterr()
    assert 'The 7-th Fibonacci number is 13' in captured.out
